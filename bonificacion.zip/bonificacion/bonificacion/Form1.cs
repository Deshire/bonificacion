﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bonificacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            //declaracion de variables
            int horasextras, horasnormales;
            double pagohnormal, pagohextra;
            byte nhijos;
            double sueldobruto, sueldoneto, bonificacion;
            Boolean marcado;
            // entrada de datos
            horasnormales = Convert.ToInt32(txthorasnormales.Text);
            horasextras = Convert.ToInt32(txthorasextras.Text);
            pagohnormal = Convert.ToInt32(txtpagohnormal.Text);
            pagohextra = Convert.ToInt32(txtpagohextra.Text);
            nhijos = Convert.ToByte(nphijos.Value);
            marcado = Convert.ToBoolean(chkbonificacion.Checked);
            // inicializar
            bonificacion = 0.0;
            // proceso
            sueldobruto = (horasnormales * pagohnormal) + (horasextras * pagohextra);
            // evaluamos si recibirá la bonificación respectiva
            if (marcado == true)
            {
                bonificacion = nhijos * 20;
            }
            sueldoneto = sueldobruto + bonificacion;

            //salida de informacion
            txtsueldobruto.Text = "$. "+Convert.ToString(sueldobruto);
            txtbonificacion.Text = "$. " + Convert.ToString(bonificacion);
            txtsueldoneto.Text = "$. " + Convert.ToString(sueldoneto);


        }

        private void btnnuevo_Click(object sender, EventArgs e)
        {
            txthorasextras.Clear();
            txtbonificacion.Clear();
            txthorasnormales.Clear();
            txtpagohextra.Clear();
            txtpagohnormal.Clear();
            txtsueldobruto.Clear();
            txtsueldoneto.Clear();
            nphijos.Value = 0;
            chkbonificacion.Checked = false;

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
